﻿using System;
namespace Entities
{
    public class CurrentUser
    {

        


    }
}
