﻿using System;
namespace Entities
{
    public class Transaction
    {
        IAccount Account { get; set; }
        double Amount { get; set; }
        DateTime TransacTime { get; set; }
        string Trans { get; set; }

        public Transaction(IAccount account, double amount, string trans)
        {
            TransacTime = DateTime.Now;
            Account = account;
            Amount = amount;
            Trans = trans;
        }

        public string GetTransacTime()
        {
            return TransacTime.ToString("F");
        }

        public double GetAmount()
        {
            return Amount;
        }

        public IAccount GetAccount()
        {
            return Account;
        }

        public string GetTrans()
        {
            return Trans;
        }
    }
}
