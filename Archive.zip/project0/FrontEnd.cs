﻿using System;
using Entities;
using BusinessLayer;
using System.Configuration;

namespace project0
{
    class MainClass
    {
        private static UserBL userBL = new UserBL();
        private static User CurrentUser = null;
        private static IAccount CurrentAccount = null;
        

        public static void Main(string[] args)
        {
            Operation1();
        }


        private static void Operation1()
        {
            string ReadInput;
            int Choice1;

            Console.WriteLine("==============================================");
            Console.WriteLine("||==========================================||");
            Console.WriteLine("||                                          ||");
            Console.WriteLine("||         Do you have an account?          ||");
            Console.WriteLine("||                                          ||");
            Console.WriteLine("||              1. Sign in                  ||");
            Console.WriteLine("||                                          ||");
            Console.WriteLine("||              2. Register                 ||");
            Console.WriteLine("||                                          ||");
            Console.WriteLine("||              3. Exit                     ||");
            Console.WriteLine("||                                          ||");
            Console.WriteLine("||==========================================||");
            Console.WriteLine("==============================================");

            //Check if the input is a 1 or 2,
            //Otherwise ask the user to re-enter 
            do
            {
                Console.Write("Enter (1 or 2 or 3): ");
                ReadInput = Console.ReadLine();

                //If the input is not a 1 or 2
                //Prints an reminder
                //If the input is 3, exits
                if(ReadInput == "3") System.Environment.Exit(0);
                else if ((ReadInput != "1") && (ReadInput != "2")) Console.WriteLine("Please enter (1/2/3)");

                Console.WriteLine("============================================");
            }
            while ((ReadInput != "1") && (ReadInput != "2"));

            Console.WriteLine();

            //Convert input to Int type and return the choice
            Choice1 = Convert.ToInt32(ReadInput);

            Operation2(Choice1);
        }

        private static void Operation2(int choice1)
        {

            switch (choice1)
            {
                case 1:
                    SignInOperation();
                    break;
                case 2:
                    RegisterOperation();
                    break;
                default:
                    break;
            }

        }

        private static void Operation3()
        {
            string choice;
            bool loop = true;

            while (loop)
            {
                Console.WriteLine($"Hi, {CurrentUser.UserName}");
                Console.WriteLine("You can perform the following operations: ");
                Console.WriteLine("1. Open a new account");
                Console.WriteLine("2. Close an account");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Deposit");
                Console.WriteLine("5. Transfer");
                Console.WriteLine("6. Pay Loan Installment");
                Console.WriteLine("7. Display list of accounts");
                Console.WriteLine("8. Display transaction for an account");
                Console.WriteLine("9. Log Out");
                Console.WriteLine();
                Console.WriteLine("Which operation do you like to perform: ");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        OpenNewAccountOperation();
                        loop = false;
                        break;
                    case "2":
                        CloseAccountOperation();
                        loop = false;
                        break;
                    case "3":
                        WithdrawOperation();
                        loop = false;
                        break;
                    case "4":
                        DepositOperation();
                        loop = false;
                        break;
                    case "5":
                        TransferOperation();
                        loop = false;
                        break;
                    case "6":
                        PayLoanOperation();
                        loop = false;
                        break;
                    case "7":
                        DisplayListOfAccountOperation();
                        loop = false;
                        break;
                    case "8":
                        TransactionOperation();
                        loop = false;
                        break;
                    case "9":
                        CurrentUser = null;
                        CurrentAccount = null;
                        loop = false;
                        Operation1();
                        break;
                    default:
                        Console.WriteLine();
                        break;
                }
            }


        }



        private static void SignInOperation()
        {
            string UserName;
            string PassWord;

            Console.WriteLine("==============================================");
            Console.WriteLine("==============================================");
            Console.WriteLine("---                                        ---");
            Console.WriteLine("===               Sign In                  ===");
            Console.WriteLine("---                                        ---");
            Console.WriteLine("==============================================");
            Console.WriteLine("==============================================");

            //if (Console.ReadLine() == "3") System.Environment.Exit(0);

            while (true)
            {
                Console.Write("Username: ");
                UserName = Console.ReadLine();
                Console.Write("Password: ");
                PassWord = Console.ReadLine();

                //Sign in
                try
                {
                    CurrentUser = userBL.GetUser(UserName, PassWord);
                    if (CurrentUser == null)
                    {
                        Console.WriteLine("There is no such existing account or the password does not matched the account!");
                        Console.Write("Do you want to go back to the previous page?(y/n)");
                        string GoBack = Console.ReadLine();
                        if (GoBack == "y") Operation1();
                        else Console.WriteLine("Please re-enter your user account.");
                    }
                    else break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            
            Console.WriteLine();
            Operation3();
        }

        private static void RegisterOperation()
        {
            string UserName;
            string PassWord;
            string Email;

            Console.WriteLine("==============================================");
            Console.WriteLine("==============================================");
            Console.WriteLine("---                                        ---");
            Console.WriteLine("===               Register                 ===");
            Console.WriteLine("---                                        ---");
            Console.WriteLine("==============================================");
            Console.WriteLine("==============================================");

            //if (Console.ReadLine() == "3") System.Environment.Exit(0);


            while(true)
            {
                Console.Write("Username: ");
                UserName = Console.ReadLine();
                Console.Write("Password: ");
                PassWord = Console.ReadLine();
                Console.Write("Email: ");
                Email = Console.ReadLine();

                try
                {
                    //Check if the accounts exists
                    //and create the account
                    int create = userBL.CreateUser(UserName, PassWord, Email);
                    if (create == 1)
                    {
                        Console.WriteLine("Failed to create the account");
                        Console.WriteLine("Please re-enter");
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("=========================================");
                        Console.WriteLine("The account has been created sucessfully!");
                        Console.WriteLine("=========================================");
                        Console.WriteLine();
                        break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            SignInOperation();

        }

        private static void OpenNewAccountOperation()
        {
            string choice;

            Console.WriteLine();
            Console.WriteLine($"Hi, {CurrentUser.UserName}");
            Console.WriteLine("You can perform the following operations: ");
            Console.WriteLine("1. Open a CheckingAccount");
            Console.WriteLine("2. Open a BusinessAccount");
            Console.WriteLine("3. Open a LoanAccount");
            Console.WriteLine("4. Open a TermDepositAccount");
            Console.WriteLine("5. Go back to previous page");
            Console.WriteLine();
            Console.WriteLine("Which operation do you like to perform: ");

            while (true)
            {
                bool next = true;
                int amount;

                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        CreateNewAccount(EnumAccountType.CheckingAccount, 0, CurrentUser);
                        break;
                    case "2":
                        CreateNewAccount(EnumAccountType.BusinessAccount, 0, CurrentUser);
                        break;
                    case "3":
                        Console.Write("Enter an amount for the new LoanAccount: ¥");
                        if(Int32.TryParse(Console.ReadLine(),out amount))
                        {
                            CreateNewAccount(EnumAccountType.LoanAccount, amount, CurrentUser);
                        }
                        else
                        {
                            Console.WriteLine("=================================");
                            Console.WriteLine("||         Invalid values       ||");
                            Console.WriteLine("=================================");
                            Console.WriteLine("Which operation do you like to perform: ");
                            next = false;
                        }
                        break;
                    case "4":
                        Console.Write("Enter an amount for the new TermDepositAccount: ¥");
                        if (Int32.TryParse(Console.ReadLine(), out amount))
                        {
                            CreateNewAccount(EnumAccountType.TermDepositAccount, amount, CurrentUser);
                        }
                        else
                        {
                            Console.WriteLine("=================================");
                            Console.WriteLine("||        Invalid values       ||");
                            Console.WriteLine("=================================");
                            Console.WriteLine("Which operation do you like to perform: ");
                            next = false;
                        }
                        break;
                    case "5":
                        Console.WriteLine();
                        break;
                    default:
                        Console.WriteLine("======================================");
                        Console.WriteLine("||  Please enter a valid operation!  ||");
                        Console.WriteLine("=======================================");
                        Console.WriteLine();
                        break;
                }

                if (next) break;
            }

            Operation3();
        }

        private static void CloseAccountOperation()
        {
            int index = 1;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of [actived] accounts: ");

                foreach (IAccount account in AccountList)
                {
                    if (account.isActive)
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();

                Console.Write("Enter account number to close the account: ");
                string accountnumber = Console.ReadLine();
                bool found = false;

                foreach(IAccount account in AccountList)
                {
                    if(accountnumber == account.AccountNumber.ToString())
                    {
                        found = true;
                        CloseAccount(account, CurrentUser);
                    }
                }

                if(found == false)
                {
                    Console.WriteLine("=================================");
                    Console.WriteLine("||  The account is not found!  ||");
                    Console.WriteLine("=================================");
                }
                Console.WriteLine();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Operation3();

        }

        private static void WithdrawOperation()
        {
            int index = 1;
            int amount;
            int accountnumber;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of [Acitived] accounts can withdraw: ");

                foreach (IAccount account in AccountList)
                {
                    if (account.isActive && (account.AccountType == EnumAccountType.BusinessAccount || account.AccountType == EnumAccountType.CheckingAccount || account.AccountType == EnumAccountType.TermDepositAccount))
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            Console.Write("Enter the accounting number that you want to withdraw: ");
            if (Int32.TryParse(Console.ReadLine(), out accountnumber))
            {
                Console.Write("Enter the amount: ¥");
                if (Int32.TryParse(Console.ReadLine(), out amount))
                {
                    WithDrawFromAccount(accountnumber, amount);
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("=================================");
                    Console.WriteLine("||        Invalid values      ||");
                    Console.WriteLine("=================================");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("=================================");
                Console.WriteLine("||        Invalid values      ||");
                Console.WriteLine("=================================");
            }

            Console.WriteLine();
            Operation3();
        }

        private static void DepositOperation()
        {
            int index = 1;
            int amount;
            int accountnumber;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of [Actived] accounts can deposit: ");

                foreach (IAccount account in AccountList)
                {
                    if (account.isActive && (account.AccountType == EnumAccountType.BusinessAccount || account.AccountType == EnumAccountType.CheckingAccount))
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            Console.Write("Enter the accounting number that you want to deposit: ");
            if (Int32.TryParse(Console.ReadLine(), out accountnumber))
            {
                Console.Write("Enter the amount: ¥");
                if (Int32.TryParse(Console.ReadLine(), out amount))
                {
                    DepositToAccount(accountnumber, amount);
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("=================================");
                    Console.WriteLine("||        Invalid values      ||");
                    Console.WriteLine("=================================");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("=================================");
                Console.WriteLine("||        Invalid values      ||");
                Console.WriteLine("=================================");
            }

            Console.WriteLine();
            Operation3();
        }

        private static void PayLoanOperation()
        {
            int index = 1;
            int amount;
            int accountnumber;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of [Actived] LoanAccounts: ");

                foreach (IAccount account in AccountList)
                {
                    if (account.isActive && (account.AccountType == EnumAccountType.LoanAccount))
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            Console.Write("Enter the accounting number that you want to deposit: ");
            if (Int32.TryParse(Console.ReadLine(), out accountnumber))
            {
                Console.Write("Enter the amount: ¥");
                if (Int32.TryParse(Console.ReadLine(), out amount))
                {
                    PayToLoan(accountnumber, amount);
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("=================================");
                    Console.WriteLine("||        Invalid values      ||");
                    Console.WriteLine("=================================");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("=================================");
                Console.WriteLine("||        Invalid values      ||");
                Console.WriteLine("=================================");
            }

            Console.WriteLine();
            Operation3();
        }

        private static void DisplayListOfAccountOperation()
        {
            int index = 1;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of accounts: ");

                foreach (IAccount account in AccountList)
                {
                    if (true)
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Operation3();
        }

        private static void TransferOperation()
        {
            int index = 1;
            int accountnumber1;
            int accountnumber2;
            int amount;

            //Get all accounts for the user
            try
            {
                Console.WriteLine();
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                var AccountList = CurrentUser.GetAllAccounts();
                Console.WriteLine("List of [Actived] Accounts: ");

                foreach (IAccount account in AccountList)
                {
                    if (account.isActive)
                    {
                        Console.Write($"[{index}]. Account Type: {account.AccountType} | Account Number: {account.AccountNumber} | isActive:{account.isActive} | Balance: ¥{account.Balance}");
                        Console.WriteLine();
                        index++;
                    }
                }
                Console.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Console.WriteLine();

            Console.Write("Account# 1: ");
            if (Int32.TryParse(Console.ReadLine(), out accountnumber1))
            {
                Console.Write("Account# 2: ");
                if (Int32.TryParse(Console.ReadLine(), out accountnumber2))
                {
                    Console.Write("Amount transfer: ¥");
                    if (Int32.TryParse(Console.ReadLine(), out amount))
                    {
                        TransferToAccount(accountnumber1, accountnumber2, amount);
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("=================================");
                        Console.WriteLine("||        Invalid values      ||");
                        Console.WriteLine("=================================");
                    }
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("=================================");
                    Console.WriteLine("||        Invalid values      ||");
                    Console.WriteLine("=================================");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("=================================");
                Console.WriteLine("||        Invalid values      ||");
                Console.WriteLine("=================================");
            }

            Console.WriteLine();
            Operation3();
        }

        private static void TransactionOperation()
        {
            int index = 1;

            Console.WriteLine();
            Console.WriteLine("----------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("List of Transactions: ");

            foreach(Transaction trans in CurrentUser.GetTransactions())
            {
                Console.WriteLine($"[{index}]. Account Type: {trans.GetAccount().AccountType} Account Number: {trans.GetAccount().AccountNumber} | {trans.GetTrans()} ¥{trans.GetAmount()} | {trans.GetTransacTime()}");
                index++;
            }
            Console.WriteLine("----------------------------------------------------------------------------------------------------------------");

            Operation3();
        }



        private static void CreateNewAccount(EnumAccountType enumaccounttype, double balance, User user)
        {
            try
            {
                userBL.CreateAccount(enumaccounttype, balance, user);
                Console.WriteLine();
                Console.WriteLine("=================================================");
                Console.WriteLine($"||  A new {enumaccounttype} has been created!  ||");
                Console.WriteLine("=================================================");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void CloseAccount(IAccount account, User user)
        {
            try
            {
                userBL.CloseAccount(account, user);
                Console.WriteLine();
                Console.WriteLine("=================================================");
                Console.WriteLine($"||  The {account.AccountType} has been deleted!  ||");
                Console.WriteLine("=================================================");
                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void WithDrawFromAccount(int accountnumber, double amount)
        {
            try
            {
                int result = userBL.WithDraw(accountnumber, amount, CurrentUser);
                if (result == 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction was proceed!  ");
                    Console.WriteLine("==================================");
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction failed!  ");
                    Console.WriteLine("==================================");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        private static void DepositToAccount(int accountnumber, double amount)
        {
            try
            {
                int result = userBL.DepoSit(accountnumber, amount, CurrentUser);
                if (result == 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction was proceed!  ");
                    Console.WriteLine("==================================");
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction failed!  ");
                    Console.WriteLine("==================================");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void PayToLoan(int accountnumber, double amount)
        {
            try
            {
                int result = userBL.PayLoan(accountnumber, amount, CurrentUser);
                if (result == 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction was proceed!  ");
                    Console.WriteLine("==================================");
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction failed!  ");
                    Console.WriteLine("==================================");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void TransferToAccount(int accountnumber1, int accountnumber2, double amount)
        {
            try
            {
                int result = userBL.Transfer(accountnumber1, accountnumber2, amount, CurrentUser);
                if (result == 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction was proceed!  ");
                    Console.WriteLine("==================================");
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("==================================");
                    Console.WriteLine("  The transaction failed!  ");
                    Console.WriteLine("==================================");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }
}
