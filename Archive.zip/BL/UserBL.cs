﻿using System;
using Entities;
using DataAccessLayer;


namespace BusinessLayer
{
    public class UserBL
    {
        public UserBL()
        {
        }


        public User GetUser(string username, string password)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var user = dal.GetUser(username, password);
                return user;
            }
            catch(Exception e)
            {
                throw;
            }

        }


        public int CreateUser(string username, string password, string email)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.CreateUser(username, password, email);
                return create;
            }
            catch(Exception e)
            {
                throw;
            }
        }



        public User CreateAccount(EnumAccountType enumaccounttype, double balance, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.CreateAccount(enumaccounttype, balance, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public User CloseAccount(IAccount account, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.CloseAccount(account, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public int WithDraw(int accountnumber, double amount, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.WithDraw(accountnumber, amount, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public int DepoSit(int accountnumber, double amount, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.DepoSit(accountnumber, amount, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public int PayLoan(int accountnumber, double amount, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.PayLoan(accountnumber, amount, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public int Transfer(int accountnumber1, int accountnumber2, double amount, User user)
        {
            UserDAL dal = new UserDAL();

            try
            {
                var create = dal.Transfer(accountnumber1, accountnumber2, amount, user);
                return create;
            }
            catch (Exception e)
            {
                throw;
            }

        }
    }
}
