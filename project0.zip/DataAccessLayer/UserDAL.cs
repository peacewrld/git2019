﻿using System;
using System.IO;
using Entities;
using Newtonsoft.Json;
using System.Collections.Generic;


namespace DataAccessLayer
{
    public class UserDAL
    {

        private static List<User> UserList = new List<User>();

        public UserDAL()
        {
        }


        public User GetUser(string username, string password)
        {
            try
            {
                foreach(User u in UserList)
                {
                    if (u.UserName == username && u.PassWord == password) return u;
                }

                return null;
            }
            catch(Exception e)
            {
                throw;
            }
        }

        public User CreateAccount(EnumAccountType enumaccounttype, double balance, User user)
        {
            Random random = new Random();

            foreach(User u in UserList)
            {
                if(u.UserName == user.UserName)
                {
                    switch (enumaccounttype)
                    {
                        case EnumAccountType.BusinessAccount:
                            u.AddBussinessAccount(random.Next(10000000, 100000000), random.Next(10000,100000));
                            break;
                        case EnumAccountType.CheckingAccount:
                            u.AddCheckingAccount(random.Next(10000000, 100000000), random.Next(10000, 100000));
                            break;
                        case EnumAccountType.LoanAccount:
                            u.AddLoanAccount(random.Next(10000000, 100000000), balance);
                            break;
                        case EnumAccountType.TermDepositAccount:
                            u.AddTermDepositAccount(random.Next(10000000, 100000000), balance);
                            break;
                        default:
                            break;
                    }
                    return u;
                }
            }

            return user;
        }

        public int CloseAccount(IAccount account, User user)
        {
            int result = 1;

            foreach (User u in UserList)
            {
                if (u.UserName == user.UserName)
                {
                    switch (account.AccountType)
                    {
                        case EnumAccountType.BusinessAccount:
                            result = u.CloseBussinessAccount((BusinessAccount)account);
                            break;
                        case EnumAccountType.CheckingAccount:
                            result = u.CloseCheckingAccount((CheckingAccount)account);
                            break;
                        case EnumAccountType.LoanAccount:
                            result = u.CloseLoanAccount((LoanAccount)account);
                            break;
                        case EnumAccountType.TermDepositAccount:
                            result = u.CloseTermDespositAccount((TermDepositAccount)account);
                            break;
                        default:
                            break;
                    }
                }
            }
            return result;
        }


        public int CreateUser(string username, string password, string email)
        {
            bool exist = false;
            User user = new User(username, password, email);

            try
            {

                foreach(User u in UserList)
                {
                    if (u.UserName == username)
                    {
                        exist = true;
                    }
                }

                if (exist == true)
                {
                    return 1;
                }

                UserList.Add(user);
                return 0;
            }
            catch(Exception e)
            {
                throw;
            }
        }


        public int WithDraw(int accountnumber, double amount, User user)
        {

            foreach (User u in UserList)
            {
                if(u.UserName == user.UserName)
                {
                    foreach(BusinessAccount b in u.GetBusinessAccounts())
                    {
                        if(b.AccountNumber == accountnumber && b.isActive == true)
                        {
                            int result = b.Withdraw(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(b, amount, "Withdraw");
                            }
                            return result;
                        }
                    }
                    foreach (CheckingAccount c in u.GetCheckingAccounts())
                    {
                        if (c.AccountNumber == accountnumber && c.isActive == true)
                        {
                            int result = c.Withdraw(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(c, amount, "Withdraw");
                            }
                            return result;
                        }
                    }
                    foreach(TermDepositAccount t in u.GetTermDepositsAccounts())
                    {
                        if (t.AccountNumber == accountnumber && t.isActive == true)
                        {
                            int result = t.Withdraw(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(t, amount, "Withdraw");
                            }
                            return result;
                        }
                    }
                }
            }
            return 1;
        }


        public int DepoSit(int accountnumber, double amount, User user)
        {
            foreach (User u in UserList)
            {
                if (u.UserName == user.UserName)
                {
                    foreach (BusinessAccount b in u.GetBusinessAccounts())
                    {
                        if (b.AccountNumber == accountnumber && b.isActive == true)
                        {
                            int result = b.Deposit(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(b, amount, "Deposit");
                            }
                            return result;
                            
                        }
                    }
                    foreach (CheckingAccount c in u.GetCheckingAccounts())
                    {
                        if (c.AccountNumber == accountnumber && c.isActive == true)
                        {
                            int result = c.Deposit(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(c, amount, "Deposit");
                            }
                            return result;
                            
                        }
                    }
                }
            }
            return 1;
        }


        public int PayLoan(int accountnumber, double amount, User user)
        {
            foreach (User u in UserList)
            {
                if (u.UserName == user.UserName)
                {
                    foreach (LoanAccount b in u.GetLoanAccounts())
                    {
                        if (b.AccountNumber == accountnumber && b.isActive == true)
                        {
                            int result = b.Payloan(amount);
                            if (result == 0)
                            {
                                u.AddTransactionRecords(b, amount, "PayLoan");
                            }
                            return result;

                        }
                    }
                }
            }
            return 1;
        }


        public int Transfer(int accountnumber1, int accountnumber2, double amount, User user)
        {
            bool CheckAccountNumber1 = false;
            bool CheckAccountNumber2 = false;

            foreach (User u in UserList)
            {
                if (u.UserName == user.UserName)
                {

                    foreach(IAccount a in u.GetAllAccounts())
                    {
                        if (accountnumber1 == a.AccountNumber)
                        {
                            CheckAccountNumber1 = true;
                        }
                        if (accountnumber2 == a.AccountNumber)
                        {
                            CheckAccountNumber2 = true;
                        }
                    }
                }
            }

            if (CheckAccountNumber1 && CheckAccountNumber2)
            {
                if(WithDraw(accountnumber1, amount, user) == 0 && ((DepoSit(accountnumber2, amount, user) == 0) || (PayLoan(accountnumber2, amount, user) == 0)))
                {
                    return 0;
                }
            }

            return 1;
        }

    }
}
