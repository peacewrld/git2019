﻿using System;

namespace Account
{
    public class Class1
    {
    }
}
