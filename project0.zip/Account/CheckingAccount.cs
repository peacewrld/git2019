﻿using System;
namespace Entities
{
    public class CheckingAccount : IAccount, IBusinessCheckingAccount
    {
        public int AccountNumber { get; set; }
        public int RoutingNumber { get; set; }
        public double Balance { get; set; }
        public bool isActive { get; set; }
        public int OpenDate { get; set; }
        public EnumAccountType AccountType { get; set; }


        public CheckingAccount(int AccountNumber, int RoutingNumber)
        {
            this.AccountNumber = AccountNumber;
            this.RoutingNumber = RoutingNumber;
            this.Balance = 0.0;
            AccountType = EnumAccountType.CheckingAccount;
            isActive = true;
        }

        public int Withdraw(double amount)
        {
            if((this.Balance - amount) >= 0)
            {
                Balance -= amount;
                return 0;
            }
            return 1;
        }

        public int Deposit(double amount)
        {
            this.Balance += amount;
            return 0;
        }
    }
}
