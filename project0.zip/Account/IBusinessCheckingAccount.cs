﻿using System;
namespace Entities
{
    public interface IBusinessCheckingAccount
    {
        int RoutingNumber { get; set; }

        int Withdraw(double amount);
        int Deposit(double amount);
    }
}
