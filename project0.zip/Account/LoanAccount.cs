﻿using System;
namespace Entities
{
    public class LoanAccount : IAccount, ILoanAccount
    {
        public int AccountNumber { get; set; }
        public double Balance { get; set; }
        public bool isActive { get; set; }
        public int OpenDate { get; set; }
        public EnumAccountType AccountType { get; set; }

        public LoanAccount(int AccountNumber, double Balance)
        {
            this.AccountNumber = AccountNumber;
            this.Balance = Balance;
            AccountType = EnumAccountType.LoanAccount;
            isActive = true;
        }

        public int Payloan(double amount)
        {
            if((Balance - amount) >= 0)
            {
                Balance -= amount;
                return 0;
            }
            return 1;
        }

    }
}
