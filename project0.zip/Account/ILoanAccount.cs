﻿using System;
namespace Entities
{
    public interface ILoanAccount
    {
        int Payloan(double amount);
    }
}
