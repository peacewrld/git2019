﻿using System;
namespace Entities
{
    public interface ITermDepositAccount
    {
        int Withdraw(double amount);
        int EndDate { get; set; }
    }
}
