﻿using System;
namespace Entities
{
    public interface IAccount
    {
        int AccountNumber { get; set; }
        double Balance { get; set; }
        bool isActive { get; set; }
        int OpenDate { get; set; }
        EnumAccountType AccountType { get; set; }
    }
}
