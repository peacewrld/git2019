﻿using System;
namespace Entities
{
    public class TermDepositAccount : IAccount, ITermDepositAccount
    {
        public int AccountNumber { get; set; }
        public double Balance { get; set; }
        public bool isActive { get; set; }

        public int OpenDate { get; set; }
        public int CurrentDate { get; set; }
        public int EndDate { get; set; }

        public EnumAccountType AccountType { get; set; }


        public TermDepositAccount(int AccountNumber, double Balance)
        {
            this.AccountNumber = AccountNumber;
            this.Balance = Balance;
            AccountType = EnumAccountType.TermDepositAccount;
            isActive = true;
        }

        public int Withdraw(double amount)
        {
            if(CurrentDate > EndDate)
            {
                if ((this.Balance - amount) >= 0)
                {
                    Balance -= amount;
                    return 0;
                }
            }
           
            return 1;
        }
    }
}
