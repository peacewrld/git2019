﻿using System;
using System.Collections.Generic;

namespace Entities
{
    public class User
    {
        public User()
        {
        }

        public User(string UserName, string PassWord, string Email)
        {
            this.UserName = UserName;
            this.PassWord = PassWord;
            this.Email = Email;
        }

        public string UserName { get; set; }
        public string PassWord { get; set; }
        public string Email { get; set; }

        List<BusinessAccount> ListBusinessAccount = new List<BusinessAccount>();
        List<CheckingAccount> ListCheckingAccount = new List<CheckingAccount>();
        List<LoanAccount> ListLoanAccount = new List<LoanAccount>();
        List<TermDepositAccount> ListTermDepositAccount = new List<TermDepositAccount>();
        List<Transaction> ListTransactions = new List<Transaction>();

        public void AddBussinessAccount(int accountnumber, int routingnumber)
        {
            BusinessAccount businessAccount = new BusinessAccount(accountnumber, routingnumber);
            ListBusinessAccount.Add(businessAccount);
        }

        public void AddCheckingAccount(int accountnumber, int routingnumber)
        {
            CheckingAccount checkingAccount = new CheckingAccount(accountnumber, routingnumber);
            ListCheckingAccount.Add(checkingAccount);
        }

        public void AddLoanAccount(int accountnumber, double balance)
        {
            LoanAccount loanAccount = new LoanAccount(accountnumber, balance);
            ListLoanAccount.Add(loanAccount);
        }

        public void AddTermDepositAccount(int accountnumber, double balance)
        {
            TermDepositAccount termDepositAccount = new TermDepositAccount(accountnumber, balance);
            ListTermDepositAccount.Add(termDepositAccount);
        }

        public void AddTransactionRecords(IAccount account, double amount, string trans)
        {
            Transaction transaction = new Transaction(account, amount, trans);
            ListTransactions.Add(transaction);
        }

        public int CloseBussinessAccount(BusinessAccount account)
        {
            foreach(BusinessAccount a in ListBusinessAccount)
            {
                if(account == a)
                {
                    if (account.Balance == 0)
                    {
                        a.isActive = false;
                        return 0;
                    }
                }
            }
            return 1;
        }

        public int CloseCheckingAccount(CheckingAccount account)
        {
            foreach (CheckingAccount a in ListCheckingAccount)
            {
                if (account == a)
                {
                    if (account.Balance == 0)
                    {
                        a.isActive = false;
                        return 0;
                    }
                }
            }
            return 1;
        }

        public int CloseLoanAccount(LoanAccount account)
        {
            foreach (LoanAccount a in ListLoanAccount)
            {
                if (account == a)
                {
                    if (account.Balance == 0)
                    {
                        a.isActive = false;
                        return 0;
                    }
                }
            }
            return 1;
        }

        public int CloseTermDespositAccount(TermDepositAccount account)
        {
            foreach (TermDepositAccount a in ListTermDepositAccount)
            {
                if (account == a)
                {
                    if (account.Balance == 0)
                    {
                        a.isActive = false;
                        return 0;
                    }
                }
            }
            return 1;
        }

        //Get a list of all accounts that the customer has
        public List<IAccount> GetAllAccounts()
        {
            List<IAccount> ListAllAccounts = new List<IAccount>();

            foreach(BusinessAccount account in ListBusinessAccount)
            {
                ListAllAccounts.Add(account);
            }

            foreach(CheckingAccount account in ListCheckingAccount)
            {
                ListAllAccounts.Add(account);
            }

            foreach(LoanAccount account in ListLoanAccount)
            {
                ListAllAccounts.Add(account);
            }

            foreach(TermDepositAccount account in ListTermDepositAccount)
            {
                ListAllAccounts.Add(account);
            }

            return ListAllAccounts;
        }

        //Get a list of all business accounts that the customer has
        public List<BusinessAccount> GetBusinessAccounts()
        {
            return ListBusinessAccount;
        }

        //Get a list of all checking accounts that the customer has
        public List<CheckingAccount> GetCheckingAccounts()
        {
            return ListCheckingAccount;
        }

        //Get a list of all loan accounts that the customer has
        public List<LoanAccount> GetLoanAccounts()
        {
            return ListLoanAccount;
        }

        //Get a list of all term deposite accounts that the customer has
        public List<TermDepositAccount> GetTermDepositsAccounts()
        {
            return ListTermDepositAccount;
        }

        public List<Transaction> GetTransactions()
        {
            return ListTransactions;
        }

    }
}
