﻿using System;
namespace Entities
{
    public enum EnumAccountType
    {
        BusinessAccount,
        CheckingAccount,
        LoanAccount,
        TermDepositAccount
    }
}
